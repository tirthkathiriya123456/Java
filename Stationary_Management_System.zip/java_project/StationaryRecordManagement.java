import java.io.*;
import java.util.*;

class Product {
    String name;
    int quantity;
    double price;
    String supplier;
    String dateAdded;

    public Product(String name, int quantity, double price, String supplier, String dateAdded) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.supplier = supplier;
        this.dateAdded = dateAdded;
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", supplier='" + supplier + '\'' +
                ", dateAdded='" + dateAdded + '\'' +
                '}';
    }
}

class Sale {
    Product product;
    int quantitySold;
    String date;

    public Sale(Product product, int quantitySold, String date) {
        this.product = product;
        this.quantitySold = quantitySold;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Sale{" +
                "product=" + product.name +
                ", quantitySold=" + quantitySold +
                ", date='" + date + '\'' +
                '}';
    }
}

public class StationaryRecordManagement {
    private Map<String, Product> products = new HashMap<>();
    private List<Sale> sales = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void preloadProducts() {
        products.put("Pen", new Product("Pen", 100, 10.0, "StationerySupplier", "2024-09-20"));
        products.put("Notebook", new Product("Notebook", 50, 30.0, "PaperSupplier", "2024-09-18"));
    }

    // Functionality 1 - Writing products to file
    public void saveProductsToFile() {
        try {
            System.out.print("Enter the file name to save product data (e.g., 'products.txt'): ");
            String outputFileName = scanner.nextLine().trim();

            if (outputFileName.isEmpty()) {
                System.out.println("Invalid input. Filename cannot be empty.");
                return;
            }

            File outputFile = new File(outputFileName);
            if (outputFile.exists()) {
                System.out.println("File exists! Do you want to overwrite it? (yes/no): ");
                String overwriteResponse = scanner.nextLine().trim().toLowerCase();
                if (!overwriteResponse.equals("yes")) {
                    System.out.println("Exiting without overwriting the file.");
                    return;
                }
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName))) {
                for (Product product : products.values()) {
                    writer.write(product.toString());
                    writer.newLine();
                }
                System.out.println("Product data saved successfully to " + outputFileName + "!");
            }

        } catch (IOException e) {
            System.out.println("An error occurred while saving data: " + e.getMessage());
        }
    }

    // Functionality 2 - Copying product file using byte stream
    public void copyProductFile() {
        try {
            System.out.print("Enter the file name to copy data from: ");
            String inputFileName = scanner.nextLine().trim();
            System.out.print("Enter the file name to copy data to: ");
            String copyFileName = scanner.nextLine().trim();

            if (inputFileName.isEmpty() || copyFileName.isEmpty()) {
                System.out.println("Invalid input. Filenames cannot be empty.");
                return;
            }

            File copyFile = new File(copyFileName);
            if (copyFile.exists()) {
                System.out.println("File exists! Do you want to overwrite it? (yes/no): ");
                String overwriteResponse = scanner.nextLine().trim().toLowerCase();
                if (!overwriteResponse.equals("yes")) {
                    System.out.println("Exiting without copying the file.");
                    return;
                }
            }

            try (FileInputStream inputFile = new FileInputStream(inputFileName);
                 FileOutputStream outputFile = new FileOutputStream(copyFileName)) {

                System.out.println("Copying data from " + inputFileName + " to " + copyFileName + "...");
                int byteData;
                while ((byteData = inputFile.read()) != -1) {
                    outputFile.write(byteData);
                }
                System.out.println("File copied successfully to " + copyFileName + "!");
            }

        } catch (IOException e) {
            System.out.println("An error occurred during file copying: " + e.getMessage());
        }
    }

    // Stationary product management functions remain the same
    public void addProduct() {
        System.out.println("Enter product details: ");
        System.out.print("Name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("Invalid input. Product name cannot be empty.");
            return;
        }

        System.out.print("Quantity: ");
        int quantity = getValidInt();
        if (quantity <= 0) {
            System.out.println("Invalid input. Quantity must be greater than zero.");
            return;
        }

        System.out.print("Price: ");
        double price = getValidDouble();
        if (price <= 0) {
            System.out.println("Invalid input. Price must be greater than zero.");
            return;
        }

        System.out.print("Supplier: ");
        String supplier = scanner.nextLine().trim();
        if (supplier.isEmpty()) {
            System.out.println("Invalid input. Supplier name cannot be empty.");
            return;
        }

        System.out.print("Date Added (YYYY-MM-DD): ");
        String dateAdded = scanner.nextLine().trim();
        if (!isValidDate(dateAdded)) {
            System.out.println("Invalid input. Date must be in the format YYYY-MM-DD.");
            return;
        }

        products.put(name, new Product(name, quantity, price, supplier, dateAdded));
        System.out.println("Product added successfully!");
    }

    public void updateProduct() {
        System.out.print("Enter product name to update: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("Invalid input. Product name cannot be empty.");
            return;
        }

        Product product = products.get(name);
        if (product != null) {
            System.out.print("Enter new quantity: ");
            int quantity = getValidInt();
            if (quantity <= 0) {
                System.out.println("Invalid input. Quantity must be greater than zero.");
                return;
            }

            System.out.print("Enter new price: ");
            double price = getValidDouble();
            if (price <= 0) {
                System.out.println("Invalid input. Price must be greater than zero.");
                return;
            }

            System.out.print("Enter new supplier: ");
            String supplier = scanner.nextLine().trim();
            if (supplier.isEmpty()) {
                System.out.println("Invalid input. Supplier name cannot be empty.");
                return;
            }

            System.out.print("Enter new date added: ");
            String dateAdded = scanner.nextLine().trim();
            if (!isValidDate(dateAdded)) {
                System.out.println("Invalid input. Date must be in the format YYYY-MM-DD.");
                return;
            }

            product.quantity = quantity;
            product.price = price;
            product.supplier = supplier;
            product.dateAdded = dateAdded;
            System.out.println("Product updated successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }

    public void deleteProduct() {
        System.out.print("Enter product name to delete: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("Invalid input. Product name cannot be empty.");
            return;
        }

        if (products.remove(name) != null) {
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }

    public void viewProducts() {
        if (products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            System.out.println("Current Products in Inventory:");
            products.values().forEach(System.out::println);
        }
    }

    public void showPreviousOrder() {
        System.out.println("Showing the previous customer's order:");
        if (!sales.isEmpty()) {
            for (Sale sale : sales) {
                System.out.println(sale);
            }
        } else {
            System.out.println("No previous orders available.");
        }
    }

    public void takeNewOrder() {
        if (products.isEmpty()) {
            System.out.println("No products available for ordering.");
            return;
        }

        System.out.println("\nNow taking a new order from the user.");
        System.out.println("Available Products:");
        int index = 1;
        for (Product product : products.values()) {
            System.out.println((index++) + ". " + product.name);
        }

        System.out.print("\nEnter the number of the product you want to order: ");
        int productIndex = getValidInt() - 1;

        if (productIndex < 0 || productIndex >= products.size()) {
            System.out.println("Invalid input. Please select a valid product number.");
            return;
        }

        Product selectedProduct = (Product) products.values().toArray()[productIndex];

        System.out.print("Enter quantity to order: ");
        int quantity = getValidInt();
        if (quantity <= 0) {
            System.out.println("Invalid input. Quantity must be greater than zero.");
            return;
        }

        if (quantity > selectedProduct.quantity) {
            System.out.println("Not enough stock available!");
            return;
        }

        String orderDate = "2024-09-25"; // Replace with LocalDate.now().toString() for real-time date
        sales.add(new Sale(selectedProduct, quantity, orderDate));

        selectedProduct.quantity -= quantity;

        System.out.println("Order placed successfully!\n");
    }

    public void showNewOrder() {
        if (!sales.isEmpty()) {
            System.out.println("Showing the new order:");
            Sale newSale = sales.get(sales.size() - 1);
            System.out.println(newSale);
        } else {
            System.out.println("No new orders to show.");
        }
    }

    private int getValidInt() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a valid integer: ");
            }
        }
    }

    private double getValidDouble() {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a valid double: ");
            }
        }
    }

    private boolean isValidDate(String date) {
        return date.matches("\\d{4}-\\d{2}-\\d{2}");
    }

    public void menu() {
        while (true) {
            System.out.println("\nStationary Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. View Products");
            System.out.println("5. Show Previous Orders");
            System.out.println("6. Take New Order");
            System.out.println("7. Show New Order");
            System.out.println("8. Save Products to File");
            System.out.println("9. Copy Product File");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            int choice = getValidInt();

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                    viewProducts();
                    break;
                case 5:
                    showPreviousOrder();
                    break;
                case 6:
                    takeNewOrder();
                    break;
                case 7:
                    showNewOrder();
                    break;
                case 8:
                    saveProductsToFile();
                    break;
                case 9:
                    copyProductFile();
                    break;
                case 10:
                    System.out.println("Exiting... Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        StationaryRecordManagement system = new StationaryRecordManagement();
        system.preloadProducts();
        system.menu();
    }
}
